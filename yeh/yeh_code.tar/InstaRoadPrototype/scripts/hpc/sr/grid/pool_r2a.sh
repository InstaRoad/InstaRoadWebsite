#!/bin/bash
#SBATCH --account=l40sfree
#SBATCH --partition=l40s
#SBATCH --qos=l40sfree
#SBATCH --job-name=r2agrid-pool
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --time=48:00:00
#SBATCH --mail-user=yhxjin001@myuct.ac.za
#SBATCH --mail-type=ALL
#SBATCH --output=slurm-%x-%j.txt
#
# THE HC-ON LANE of the lr_sr mechanism grid: r2a's configuration (SEN2SR-Lite
# with its native hard constraint, SR_PAD=8) at all four pinned lr_sr values.
# docs/lrsr_grid_ablation_plan.md — the r2b lane is pool_r2b.sh.
#
#   sbatch scripts/hpc/sr/grid/pool_r2a.sh
#
# No flags: the headers above are the ones you would otherwise type. Note that
# they only apply when this file is submitted DIRECTLY — sbatch reads #SBATCH
# from the file it is given, so routing it through train.sbatch instead
# (`sbatch --job-name=... --time=48:00:00 --gres=gpu:1 --cpus-per-task=8 \
#   scripts/hpc/train.sbatch --SCRIPT=sr/grid/pool_r2a.sh`) ignores them and you
# are back to passing the flags yourself. Everything train.sbatch does for an
# arm — export the config, exec the script — this pool does for four cells.
#
# --output=slurm-%x-%j.txt, not train.sbatch's slurm-%j.txt: the whole point of
# two lanes is telling them apart, and %x is the job name. Still .txt, so
# Nextcloud renders it.
#
# WHAT IT RUNS
# ------------
# Four cells x (tune -> fit -> bench), sequentially on one GPU, extremes first
# per §8: 1e-4 and 1e-5 carry the interaction and the probable collapses; the
# 1e-6/1e-7 cells interpolate toward the formal r2a arm and are the least
# informative, so they run last and are the ones a timeout drops.
#
# 48 h is a budget, not a promise. Per cell is roughly a 15x10 lr tune (pruned,
# cheap) plus a 2-3 h refit, so the lane usually fits — but if it does not, just
# SUBMIT IT AGAIN: every stage is guarded by what it would produce, so finished
# cells cost seconds and a half-trained refit resumes from last.ckpt.
#
#   LRSRS="1e-4"           only that cell
#   STAGES="tune"          all four tunes first, fits later
#   STAGES=refit SEEDS="1 2"
#                          replicate seeds for a cell that carries a
#                          quantitative sentence (§2), through
#                          grid/refit/r2grid_on_ls<rate>.sh — which plants that
#                          cell's BAKED overlay per seed. Do NOT reach for
#                          SEED=1 with the default stages instead: that would
#                          re-tune the cell and hand the seed its own lr, which
#                          is a different arm, not a replicate.
set -euo pipefail
REPO_DIR="${REPO_DIR:-$HOME/InstaRoad/InstaRoadPrototype}"

export HC=on
export LRSRS="${LRSRS:-1e-4 1e-5 1e-6 1e-7}"

bash "$REPO_DIR/scripts/hpc/sr/grid/run_pool.sh"
