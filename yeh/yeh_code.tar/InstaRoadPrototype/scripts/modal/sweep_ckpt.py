"""One-off θ* sweep for a SINGLE checkpoint on Modal (docs/demo_hosting_plan.md §8).

`modal_app.sweep` sweeps every arm of the loss pilot off the Volume. This is
the narrower thing: point it at one checkpoint and get one sweep.json, using
the SAME `benchmarking.cli sweep` entry point every other arm's θ* came from,
so the number is commensurable rather than merely plausible.

WHY NOT LOCALLY
---------------
SR4RS is the heavy arm -- it OOMed a 24 GB L4 at batch size 4, which is why
that lane moved off the Studio. Measured on an 8 GB Mac: ~110-120 s/tile on
MPS (the CPU path gets OOM-killed outright), so 190 val tiles is ~6-7 hours.
On an L4 it is minutes.

Image, volumes and mounts are imported from `modal_app` rather than redefined
-- the repo mount deliberately EXCLUDES *.ckpt and *.safetensors, so weights
must already live on the Volumes:

    modal volume put instaroad-data  models/SR4RS_RGBN/gen_weights.safetensors \
                                     /models/SR4RS_RGBN/gen_weights.safetensors
    modal volume put instaroad-runs  <run>/checkpoints/<ckpt> /runs/<run>/checkpoints/<ckpt>

Run it DETACHED. `modal run` alone dies with the client, and a re-run re-does
the whole sweep:

    modal run --detach scripts/modal/sweep_ckpt.py
"""
from __future__ import annotations

import os
import subprocess
import sys

import modal

# Modal copies the ENTRYPOINT to /root/sweep_ckpt.py, but `modal_app` lives
# inside the mounted repo at /root/InstaRoadPrototype/scripts/modal/ -- which
# is not on sys.path in the container. Importing it works locally (same dir)
# and fails remotely, so resolve both before importing.
for _cand in (os.path.dirname(os.path.abspath(__file__)),
              "/root/InstaRoadPrototype/scripts/modal"):
    if os.path.isfile(os.path.join(_cand, "modal_app.py")) and _cand not in sys.path:
        sys.path.insert(0, _cand)

from modal_app import DATA_MNT, OUT_MNT, REPO_REMOTE, VOLUMES, image, runs_vol

app = modal.App("instaroad-sweep-ckpt", image=image)

RUN = "sr_rl4_full_nohc_linear_gap_ce_anorm_recalpost_rails_seed666"
CKPT = "unet_s2rosa_jointsr_epoch050.ckpt"


@app.function(gpu="L4", volumes=VOLUMES, cpu=4.0, memory=16384,
              timeout=3 * 3600)
def sweep(
    run: str = RUN,
    ckpt: str = CKPT,
    model_name: str = "sr_rl4_full_nohc_linear_gap_ce_anorm_recalpost_rails_ap",
    split: str = "val",
    criterion: str = "iou",
    seed: int = 666,
    sen2sr_dir: str = f"{DATA_MNT}/models/SR4RS_RGBN",
    mask_dirname: str = "mask_new_2pt5",
    thresholds: str = "0.05:0.95:0.05",
    max_tiles: int = 0,
    out_name: str = "",
) -> str:
    run_dir = f"{OUT_MNT}/runs/{run}"
    stem = ckpt[:-5] if ckpt.endswith(".ckpt") else ckpt
    out = f"{run_dir}/{out_name or 'sweep_' + stem + '.json'}"
    cmd = [
        sys.executable, "-u", "-m", "benchmarking.cli", "sweep",
        "--dataset-dir", f"{DATA_MNT}/ROSA_New",
        "--checkpoint", f"{run_dir}/checkpoints/{ckpt}",
        "--model-name", model_name,
        "--model", "sr", "--split", split, "--seed", str(seed),
        "--device", "cuda",
        "--mask-source", "raster", "--mask-dirname", mask_dirname,
        "--sen2sr-dir", sen2sr_dir,
        "--criterion", criterion, "--thresholds", thresholds,
        "--out", out,
    ]
    if max_tiles:
        cmd += ["--max-tiles", str(max_tiles)]

    print(" ".join(cmd), flush=True)
    r = subprocess.run(cmd, cwd=REPO_REMOTE,
                       env={"PYTHONPATH": f"{REPO_REMOTE}/src",
                            "PYTHONUNBUFFERED": "1", "PATH": "/usr/bin:/bin:/usr/local/bin",
                            "HOME": "/root"})
    runs_vol.commit()                 # persist before the container dies
    if r.returncode:
        raise RuntimeError(f"sweep exited {r.returncode}")
    print(f"\nwrote {out}", flush=True)
    return out


@app.local_entrypoint()
def main(max_tiles: int = 0, split: str = "val", criterion: str = "iou"):
    print(sweep.remote(max_tiles=max_tiles, split=split, criterion=criterion))
