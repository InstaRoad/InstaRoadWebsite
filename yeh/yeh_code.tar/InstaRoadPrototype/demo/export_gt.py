"""Export mask_new_2pt5 ground truth for the demo (plan §5 Phase 2b).

VERIFIED ALIGNMENT, not assumed: the GT raster is 2048x2048 at 2.5 m with
bounds IDENTICAL to its 512x512 10 m imagery tile, so it registers
pixel-for-pixel against the x4 SR output with no resampling. This script
re-asserts that per tile rather than trusting one spot check.

PNG, not .npy: a binary 2048^2 mask is 512 KB raw but compresses to tens of KB,
and PIL reads it in the Space without dragging GDAL/PROJ into the image.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image

ROOT = Path("/Volumes/MAC_KIOXIA/Data/ROSA_New/ROSADataset")
DEFAULT_OUT = Path("/Volumes/KIOXIA/instaroad_demo_export")
GT_DIRNAME = "mask_new_2pt5"
SCALE = 4                       # 10 m tile -> 2.5 m GT


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--splits", nargs="+", default=["test", "val", "train"])
    ap.add_argument("--manifest", type=Path,
                    default=Path(__file__).parent / "cells.json")
    args = ap.parse_args()

    cells = [c for c in json.loads(args.manifest.read_text())
             if c["split"] in args.splits]
    gt_dir = args.out / "gt"
    gt_dir.mkdir(parents=True, exist_ok=True)

    n = nbytes = 0
    frac = []
    for c in cells:
        src = ROOT / c["split"] / GT_DIRNAME / f"{c['id']}.tif"
        with rasterio.open(src) as ds:
            a = ds.read(1)
            b = [round(v, 3) for v in ds.bounds]
        exp = [round(v, 3) for v in c["bounds_utm"]]
        assert b == exp, f"{c['id']}: GT bounds {b} != imagery {exp}"
        assert a.shape == (c["px"][1] * SCALE, c["px"][0] * SCALE), \
            f"{c['id']}: GT {a.shape} is not {SCALE}x the imagery grid"
        assert set(np.unique(a).tolist()) <= {0, 1}, f"{c['id']}: GT not binary"

        out = gt_dir / f"{c['id']}.png"
        Image.fromarray((a * 255).astype(np.uint8)).save(out, optimize=True)
        nbytes += out.stat().st_size
        frac.append(float(a.mean()))
        n += 1
        if n % 200 == 0:
            print(f"  {n}/{len(cells)}")

    print(f"\n{n} GT masks  ->  {nbytes/1e6:.1f} MB  ({nbytes/max(n,1)/1e3:.0f} KB each)")
    print(f"road fraction: min {min(frac):.4f}  median {sorted(frac)[len(frac)//2]:.4f}  "
          f"max {max(frac):.4f}")
    print("alignment asserted on every tile: bounds identical, grid exactly 4x")


if __name__ == "__main__":
    main()
