# Public demo: InstaGeo fork on Render + ZeroGPU inference

Status: BUILT — r2a end to end; rl4 pending its θ* sweep. Written 2026-09-20.
Scope: a public, zero-cost demo of **r2a** (joint SEN2SR-Lite + ResNet34 U-Net)
and **rl4** (1×1 logistic head on task-adapted SR4RS) over the ROSA_New
sampling zones. A Render static site serves the UI; a Hugging Face ZeroGPU
Space runs inference; an HF dataset holds the imagery. No live GEE, no backend,
no paid tier anywhere.

Every number below is measured, not estimated.

## 1. Architecture

```
Browser ──────────────► Render Static Site   (free CDN, no spin-down)
   │                    demo/instaroad-static, Vite + React + Leaflet
   │
   ├──HF CDN──────────► chips/<cell>.jpg     (85 KB, public dataset)
   │
   └──@gradio/client──► ZeroGPU Space        (free, Gradio SDK, @spaces.GPU)
                          │  r2a weights baked in (110 MB bundle)
                          └─hf_hub_download─► tiles/<cell>.npy (2.1 MB)
```

No server of ours executes anything. The browser sends a **cell id**, never
pixels. Two decisions drive the whole shape:

* **Render static, not web service.** Static sites are CDN-served and never
  spin down; free *web* services sleep after 15 min, cap at 512 MB, and have
  no background workers at all — which `instageo/new_apps`' Redis/RQ stack
  requires. Dropping the backend removed the spin-down problem, the uptime
  bot, and ~2,500 lines of job orchestration in one move.
* **The browser calls the Space directly.** ZeroGPU bills its daily quota to
  the *caller* (2 min unauthenticated, 5 min free, 40 min PRO). Proxying
  through a server would make one token's allowance the ceiling for every
  visitor combined; called from the browser, each visitor spends their own.

## 2. Live resources

| What | Where | State |
|---|---|---|
| Static UI | `demo/instaroad-static/` → `github.com/Goamhobala/InstaRoad-static` | pushed, `4717aaa` |
| Render | static site on that repo | build `npm ci && npm run build`, publish `dist` |
| Tiles + chips | `hf.co/datasets/Goamhobala/instaroad-rosa-tiles` | 2,499 files, 2.7 GB, **public** |
| r2a weights | `hf.co/Goamhobala/instaroad-sr-ckpts` | private (baked into the Space) |
| Space | `hf.co/spaces/Goamhobala/instaroad-demo` | ZeroGPU, private |

**Creating the Space requires ZeroGPU hardware at CREATE time.** A Gradio
Space on the default `cpu-basic` now returns `402 Payment Required` (that tier
needs PRO), while ZeroGPU hosting is free for accounts in good standing. There
is no create-cheap-then-upgrade path; `bundle.py` passes
`space_hardware="zero-a10g"` on the first call.

## 3. What the data and checkpoints establish

**Bands.** The GEE export writes 23 bands; 1–4 are `B4,B3,B2,B8` at **0–1
reflectance** (the script already applies `.divide(10000)`, which is why both
checkpoints carry `reflectance_scale: 1.0`). 5–10 remaining S2, 11–14 S1
asc/desc dB, 15–20 topo, 21–23 ESA/GISA/WSF urban. **Band order is
load-bearing**: red first, not natural RGB.

**Checkpoints.**

| | r2a | rl4 |
|---|---|---|
| run | `sr_r2a_new_gap_ce_anorm_recalpost_seed42` | `sr_rl4_full_nohc_linear_gap_ce_anorm_recalpost_rails_seed666` |
| file | `unet_s2rosa_jointsr_final.ckpt` (epoch 100) | `unet_s2rosa_jointsr_epoch050.ckpt` (epoch 49) |
| stripped | 298.8 → **101.6 MB** | 129 MB → ~45 MB |
| upsampler / `sr_hc` | `sen2sr` / `native` | `sr4rs` / `off` |
| head | ResNet34 U-Net, 278 tensors | `model.conv (1,4,1,1)` + bias |
| window | **128 px** (forced) | **256 px** (bench cell) |
| θ* | **0.70** | pending sweep |

Both carry `adaptive_norm: True`, so `band_mean`/`band_std` in the state_dict
are EMA'd post-SR moments — load them, never recalibrate at serve time.

**θ\* = 0.70 is a near-tie.** On val, f1_macro is 0.6375747 at 0.70 vs
0.6375639 at 0.75 — 1e-5 — and **iou_macro actually peaks at 0.75**
(0.50444 vs 0.50354). Correct for its stated criterion, but if the demo ever
displays IoU it is showing the operating point that loses on that metric.

**Data.** 1,247 tiles / 60 sites, 512² at 10 m, per-site UTM, splits
**site-disjoint** (42 train / 9 val / 9 test sites). A site is a 5×5 sheet of
tiles = 25.6 km, matching the GEE script's 25 km box. Sites hold 12–25 tiles;
QC dropped the rest. The 9 test sites span 9 biomes across Urban/PeriUrban/
Rural, and every tile has `mask_new_2pt5` ground truth.

**Site names need a lookup table, not a parse.** Five of 60 fail a
biome-vocabulary match (`Carnarvon`, `Kenhart`, `Soebatsfontein` carry no
biome; `Durban`/`RichardsBay` say `IndianCoastal`), and `Knysna_Forest` vs
`Forests_…` splits one biome in two. The GEE script's comment groupings are
the only record; they are transcribed into `OVERRIDES` in `build_manifest.py`.

## 4. The grid

```
atom = 128 px = r2a's forced SEN2SR window (model._required_lr)
tile = 512 px = 4x4 atoms                  <- the stored unit
site = 5x5 tiles = 25.6 km
```

| UI size | Legal selections | Ground |
|---|---|---|
| 128² | 19,952 | 1.28 km |
| 256² | 4,988 | 2.56 km |
| 512² | 1,247 | 5.12 km |
| 1024² | **672** | 10.24 km |

Sizes 128/256/512 are size-aligned and never cross a tile boundary. Only 1024
does, and only across whole tiles. **Contiguity is asserted, not assumed**:
all 672 candidate 2×2 quads were checked against real UTM bounds — max gap
**0.0000 m**.

The UI computes no legality. `selections.json` ships the legal set, because
two implementations of that arithmetic — JS for the map, Python for inference
— is two chances to drift, and a drift here is silent: the mask simply lands
on the wrong ground.

## 5. Files

| Path | Does |
|---|---|
| `demo/build_manifest.py` | `sites.json` + `cells.json` from GeoTIFF bounds |
| `demo/build_selections.py` | `selections.json`; asserts 1024 contiguity |
| `demo/export_tiles.py` | 4-band fp16 `.npy` + per-site-stretched JPEG chips |
| `demo/strip_ckpt.py` | training ckpt → serving ckpt; cross-checks θ* vs `sweep.json` |
| `demo/space/infer.py` | windowed replay, mirrors `sr.viz_tile.run_tile` |
| `demo/space/parity.py` | the gate (§6) |
| `demo/space/app.py` | Gradio `/predict`, `@spaces.GPU` |
| `demo/space/bundle.py` | assembles + pushes the Space |
| `demo/instaroad-static/` | the UI (submodule) |

`demo/*.py` is the only copy outside the session that produced it — commit it.

## 6. The parity gate

`demo/space/parity.py` asks two separate questions rather than one blurred one.

**A — does the serving path replay the checkpoint the way the bench does?**
Feed `infer.py` and `sr.viz_tile.run_tile` the *identical* array; any
difference is windowing, not data. **PASSED on MPS: max|Δ SR| = 0.000e+00 and
max|Δ prob| = 0.000e+00 — bit identical.**

**B — what does fp16 tile storage cost?** Source fp32 GeoTIFF through the
reference vs the shipped fp16 `.npy` through the serving path:

| | |
|---|---|
| max \|Δ prob\| | 5.19e-2 |
| mask pixels flipped at θ* | 1,220 / 4,194,304 (**0.029%**) |
| road px, fp32 → fp16 | 455,894 → 455,772 |
| IoU between masks | **0.9973** |

A 2.4e-4 input perturbation amplifies ~200× into probability. It only matters
within a hair of θ*, which is why the flip count stays at 0.03% — but it is
the reason to quote the mask IoU rather than call fp16 free.

This gate exists because the two known failure modes here — reflectance-scale
coupling and eval-collapsed SEN2SR convs — produce a plausible-but-wrong mask,
never an exception.

## 6b. Cross-environment parity (deployed Space vs local)

The gate in §6 ran locally. The Space is a different environment — Python 3.10,
lightning 2.6.6, gradio 6.28.0, CUDA instead of MPS — so the numbers were
re-measured against the live Space, masks returned as PNG:

| site | size | disagreeing px | mask IoU |
|---|---|---|---|
| CapeTown Fynbos | 512² | 2,716 / 4,194,304 (0.0648%) | 0.9961 |
| Savanna | 256² | 356 / 1,048,576 (0.0340%) | 0.9919 |
| AlexanderBay Desert | 128² | 0 / 262,144 (0.0000%) | — both masks empty |
| **total** | | **3,072 / 5,505,024 (0.0558%)** | |

Road fraction agrees to 5 decimals (0.16597 remote vs 0.16599 local). The
residual is genuine numerical drift across CUDA/MPS and the lightning version
gap, and is the same order as the fp16 storage effect in §6B.

**Gradio 6 returns images as lossy WebP** — a binary mask came back with 36
distinct grey values, 0.12% of pixels intermediate. The mask output is now
`format="png"` so the artifact is exact. Note this did NOT change the parity
numbers: thresholding at >127 recovered the binarisation regardless, and the
0.0648% was numerical all along. The PNG is correctness insurance, not a fix
for a measured error.

The desert row is a reminder that IoU is undefined when both masks are empty;
the 0.000000 printed there is a divide-by-zero guard, not a failure.

## 7. Measured behaviour

Timings on local MPS (ZeroGPU is several× faster):

| size | 128² | 256² | 512² | 1024² |
|---|---|---|---|---|
| local MPS | 0.9 | 0.7 | 2.7 | 10.9 |
| ZeroGPU | 0.46 | — | 2.07 | — |

ZeroGPU is only ~25% faster than the Mac at 512². Round-trip is dominated by
shipping 2048² panels back (31s cold, 6.6s for a 128² selection), not by
inference — so the lever on perceived speed is smaller returned panels, not
more GPU.

Sanity: urban Cape Town 16.6% road fraction vs rural Savanna 5.4%.

Storage: 4-band fp16 is **2.10 MB/tile** (2.62 GB all in) against 24.1 MB for
the 23-band fp32 source. Chips are **85 KB** JPEG (PNG would be ~4×, and chips
are the bandwidth line item).

## 8. Remaining

1. **UI ↔ Space**: verify `@gradio/client` reaches the Space from the Render
   origin (CORS), and confirm the UI renders against live chips.
2. **rl4** — sweep θ* on val for `epoch050` (the stock 0.75 belongs to
   `last`/`final`), then `strip_ckpt.py --arm rl4 --window-px 256
   --threshold <θ*>`, rebundle, and flip `ready: true` in the UI's
   `config.js`. No new infrastructure.
3. **Publish**: Space public, README linking the thesis, note that InstaGeo is
   CC-BY-NC-SA-4.0 (ShareAlike propagates to the fork).

## 9. Open risks

* **Browser → ZeroGPU CORS** is untested from a third-party origin.
  `@gradio/client` is built for it; fallback is embedding the Space in an
  iframe — uglier, still per-visitor quota.
* **Cold start.** Spaces sleep when idle; the first call pays a container pull
  plus model load. Wake it before any live demo.
* **`mask_new_2pt5` alignment** — confirm the 2.5 m GT is pixel-aligned with
  the ×4 SR output before drawing them as overlapping panels.
* **Untracked work is fragile.** A submodule restructure on 2026-09-20 wiped
  everything untracked under `demo/` and `docs/`. All of this plan's artifacts
  were recoverable (weights and manifests from the Hub, scripts rewritten and
  re-verified bit-identical); ten of the repo's own uncommitted `*_plan.md`
  docs were not.
