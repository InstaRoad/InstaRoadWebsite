from importlib.resources import files
from pathlib import Path
from typing import Any, Dict

VARIANTS: Dict[str, Dict[str, Any]] = {
    "sgcn": {"config": "sgcn", "gee_band_list": "s1s2"},
    "unet": {"config": "unet", "gee_band_list": "s1s2"},
    "terramind_base": {"config": "terramind", "gee_band_list": "s1s2"},
    "sam_rgb": {"config": "sam", "gee_band_list": "rgb"},
}


def config_path(stem: str) -> Path:
    """Filesystem path of a samroad YAML inside the installed geosamroad package."""
    path = Path(str(files("geosamroad") / "configs" / "hpc" / f"{stem}.yaml"))
    if not path.exists():
        raise FileNotFoundError(
            f"geosamroad has no config {stem!r} at {path}"
        )
    return path


def get_variant(size: str) -> Dict[str, Any]:
    if size not in VARIANTS:
        raise KeyError(
            f"Unknown GeoSAMRoad variant {size!r}, expected one of {sorted(VARIANTS)}"
        )
    variant = dict(VARIANTS[size])
    variant["config_path"] = config_path(variant["config"])
    return variant
