import glob
import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

import cv2  # opencv-python-headless
import numpy as np
import rasterio
import torch
from rasterio.transform import from_bounds
from rasterio.windows import Window

from geosamroad import triage
from geosamroad.dataset.bands import RGB, resolve_input
from geosamroad.dataset.helper import read_upsampled_window, read_window
from geosamroad.inferencer import NATIVE_TILE_PX, infer_one_tile, patch_offsets
from geosamroad.models.model import GeoSAMRoad
from geosamroad.utils import finalize_config, load_config

from instageo.model.geosamroad_runner.variants import get_variant

logger = logging.getLogger(__name__)

UPSCALE = 2
INFER_PATCHES_PER_EDGE = 16

TRUE_COLOR_RGB = RGB              # (1, 2, 3) -> B4_R, B3_G, B2_B
TRUE_COLOR_MAX_REFL = 0.30        # reflectance value mapped to white
TRUE_COLOR_GAMMA = 0.8            # mild shadow brightening (<1 brightens)

# Graph overlay weight, in rendered pixels. A 512 px tile at 10 m/px drawn at
# up_size = 1024 means 1 rendered px = 5 m on the ground, so:
#   edge_thickness 2 -> a 10 m line, about one real two-lane road
#   node_radius    2 -> a 20 m dot at each intersection
# geosamroad's own defaults are 4/4 (a 20 m line and a 40 m dot), which swamp
# the imagery. Drop either to 1 for a finer overlay.
GRAPH_NODE_RADIUS = 2
GRAPH_EDGE_THICKNESS = 2


def pick_device(name: str = "auto") -> torch.device:
    """Resolve the torch device"""
    if name != "auto":
        return torch.device(name)
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def _find_checkpoint(checkpoint_dir: str) -> str:
    ckpts = sorted(glob.glob(os.path.join(checkpoint_dir, "*.ckpt")))
    if not ckpts:
        raise FileNotFoundError(
            f"No GeoSAMRoad checkpoint (*.ckpt) found in {checkpoint_dir}"
        )
    if len(ckpts) > 1:
        logger.warning("Multiple checkpoints in %s; using %s", checkpoint_dir, ckpts[0])
    return ckpts[0]


def load_model(
    checkpoint_dir: str,
    model_size: str,
    dataset_dir: str = ".",
    device: Optional[torch.device] = None,
):
    device = device or pick_device("auto")
    variant = get_variant(model_size)
    config = load_config(str(variant["config_path"]))

    config.DATASET_DIR = dataset_dir

    config.PRETRAINED = False
    config.UPSCALE = UPSCALE
    config.INFER_PATCHES_PER_EDGE = INFER_PATCHES_PER_EDGE
    finalize_config(config) 

    patch_offsets(
        NATIVE_TILE_PX * UPSCALE, int(config.PATCH_SIZE), INFER_PATCHES_PER_EDGE
    )

    bands = list(
        resolve_input(
            str(config.ENCODER_MODEL),
            bool(config.RGB_INPUT),
            config.get("RGB_SOURCE") or "enhanced",
        )
    )

    checkpoint = _find_checkpoint(checkpoint_dir)
    logger.info(
        "Loading GeoSAMRoad checkpoint: %s (size=%s, encoder=%s, bands=%s)",
        checkpoint,
        model_size,
        config.ENCODER_MODEL,
        bands,
    )
    net = GeoSAMRoad(config)
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)

    result = net.load_state_dict(state["state_dict"], strict=False)
    if result.missing_keys:
        raise RuntimeError(
            f"Checkpoint {checkpoint} is missing {len(result.missing_keys)} model "
            f"weights, first few: {result.missing_keys[:5]}"
        )
    if result.unexpected_keys:
        logger.info(
            "Ignored %d non-parameter key(s) in the checkpoint (e.g. %s)",
            len(result.unexpected_keys),
            result.unexpected_keys[:3],
        )
    net.eval().to(device)
    return net, config, bands, device


def _write_rgb_geotiff(
    array_hwc: np.ndarray, path: str, crs: Any, transform: Any
) -> None:
    height, width, _ = array_hwc.shape
    profile = {
        "driver": "GTiff",
        "height": height,
        "width": width,
        "count": 3,
        "dtype": "uint8",
        "crs": crs,
        "transform": transform,
        "compress": "deflate",
        "tiled": True,
        "blockxsize": 512,
        "blockysize": 512,
    }
    with rasterio.open(path, "w", **profile) as dst:
        for b in range(3):
            dst.write(array_hwc[:, :, b], b + 1)


def infer_tile(
    net,
    config,
    bands,
    device: torch.device,
    tile_path: str,
    chips_dir: str,
    predictions_dir: str,
) -> Dict[str, int]:
    upscale = int(config.UPSCALE)
    up_size = NATIVE_TILE_PX * upscale
    win = Window(0, 0, NATIVE_TILE_PX, NATIVE_TILE_PX)
    display_bands = list(TRUE_COLOR_RGB)

    with rasterio.open(tile_path) as src:
        if upscale > 1:
            img = read_upsampled_window(src, list(bands), win, up_size)
            raw = read_upsampled_window(src, display_bands, win, up_size)
        else:
            img = read_window(src, list(bands), win)
            raw = read_window(src, display_bands, win)
        crs = src.crs
        left, bottom, right, top = src.bounds

    image = torch.from_numpy(np.ascontiguousarray(img))

    disp = np.clip(raw / TRUE_COLOR_MAX_REFL, 0.0, 1.0) ** TRUE_COLOR_GAMMA
    rgb = (disp.transpose(1, 2, 0) * 255).astype(np.uint8)

    pred_nodes, pred_edges, _itsc_mask, _road_mask = infer_one_tile(
        net, image, config, device
    )

    if pred_nodes.shape[0]:

        viz_bgr = triage.visualize_image_and_graph(
            rgb,
            pred_nodes / up_size,
            pred_edges,
            up_size,
            node_radius=GRAPH_NODE_RADIUS,
            edge_thickness=GRAPH_EDGE_THICKNESS,
        )
    else:
        viz_bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    viz_rgb = cv2.cvtColor(viz_bgr, cv2.COLOR_BGR2RGB)

    transform = from_bounds(left, bottom, right, top, up_size, up_size)
    stem = Path(tile_path).stem
    _write_rgb_geotiff(rgb, os.path.join(chips_dir, f"chip_{stem}.tif"), crs, transform)
    _write_rgb_geotiff(
        viz_rgb, os.path.join(predictions_dir, f"prediction_{stem}.tif"), crs, transform
    )
    return {"nodes": int(pred_nodes.shape[0]), "edges": int(pred_edges.shape[0])}


def run_geosamroad_inference(
    data_dir: str,
    checkpoint_dir: str,
    model_size: str = "sam_rgb",
    device_name: str = "auto",
) -> Dict[str, Any]:
    data_path = Path(data_dir)
    imagery_dir = data_path / "imagery"
    tiles = sorted(glob.glob(str(imagery_dir / "*.tif")))
    if not tiles:
        raise FileNotFoundError(f"No GEE tiles found under {imagery_dir}")

    chips_dir = data_path / "chips"
    predictions_dir = data_path / "predictions"
    chips_dir.mkdir(parents=True, exist_ok=True)
    predictions_dir.mkdir(parents=True, exist_ok=True)

    device = pick_device(device_name)
    net, config, bands, device = load_model(
        checkpoint_dir, model_size, dataset_dir=str(data_path), device=device
    )
    logger.info(
        "GeoSAMRoad (%s) running on %s over %d tile(s)", model_size, device, len(tiles)
    )

    total_nodes = total_edges = 0
    for i, tile in enumerate(tiles):
        stats = infer_tile(
            net, config, bands, device, tile, str(chips_dir), str(predictions_dir)
        )
        total_nodes += stats["nodes"]
        total_edges += stats["edges"]
        logger.info(
            "[%d/%d] %s: %d nodes, %d edges",
            i + 1,
            len(tiles),
            Path(tile).name,
            stats["nodes"],
            stats["edges"],
        )

    return {
        "tiles_processed": len(tiles),
        "total_nodes": total_nodes,
        "total_edges": total_edges,
    }


__all__ = ["run_geosamroad_inference", "load_model", "infer_tile", "pick_device"]
