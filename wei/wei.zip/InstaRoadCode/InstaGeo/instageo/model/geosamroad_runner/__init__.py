from instageo.model.geosamroad_runner.variants import VARIANTS, get_variant

__all__ = ["VARIANTS", "get_variant", "run_geosamroad_inference"]


def __getattr__(name):
    if name == "run_geosamroad_inference":
        from instageo.model.geosamroad_runner.runner import run_geosamroad_inference

        return run_geosamroad_inference
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
