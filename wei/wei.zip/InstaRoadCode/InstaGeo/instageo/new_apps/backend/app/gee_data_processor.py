"""Google Earth Engine data source for the InstaGeo backend."""
import json
import logging
import os
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

logging.getLogger(__name__)
logger = logging.getLogger(__name__)

COMPOSITE_HALF_WINDOW_DAYS = 182
DEFAULT_GEE_BAND_LIST = "s1s2"


def _band_list_for_size(model_size: str) -> str:
    """Return the globalurbanmapper_gee band list for a model size."""
    try:
        from instageo.model.geosamroad_runner.variants import get_variant

        return get_variant(model_size)["gee_band_list"]
    except Exception:
        logger.warning(
            "No band list for model_size=%r; falling back to %r",
            model_size,
            DEFAULT_GEE_BAND_LIST,
        )
        return DEFAULT_GEE_BAND_LIST


def _resolve_credentials() -> Dict[str, str]:
    key_file = os.getenv("GEE_PRIVATE_KEY_FILE", "").strip()
    if not key_file or not os.path.exists(key_file):
        raise RuntimeError(
            "GEE_PRIVATE_KEY_FILE is not set or does not exist. Point it at the "
            "service-account JSON key (see instageo/new_apps/.env)."
        )
    with open(key_file) as f:
        key = json.load(f)
    project = (
        os.getenv("GEE_PROJECT")
        or os.getenv("GEE_PROJECT_NAME")
        or key.get("project_id")
    )
    return {
        "project": (project or "").strip().strip("'\""),
        "service_account": key.get("client_email"),
        "key_file": key_file,
    }


def _composite_window(date_str: str) -> tuple[str, str]:
    target: Optional[datetime] = None
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%Y/%m/%d", "%d/%m/%Y"):
        try:
            target = datetime.strptime((date_str or "").strip(), fmt)
            break
        except (ValueError, TypeError):
            continue
    if target is None:
        logger.warning("Could not parse date '%s'; using today.", date_str)
        target = datetime.utcnow()
    start = target - timedelta(days=COMPOSITE_HALF_WINDOW_DAYS)
    end = target + timedelta(days=COMPOSITE_HALF_WINDOW_DAYS)
    return start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")


class GEEDataProcessor:
    def __init__(self, base_output_dir: str = "/app/instageo-data"):
        """
        Args:
            base_output_dir: Base directory for storing task outputs.
        """
        self.base_output_dir = Path(base_output_dir)
        self.base_output_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir: Optional[Path] = None
        self.chips_created: bool = False

    def extract_data_from_bboxes(
        self,
        task_id: str,
        bboxes: List[List[float]],
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Fetch imagery for the bounding boxes from Google Earth Engine.

        Args:
            task_id: Unique task identifier.
            bboxes: List of [minx, miny, maxx, maxy] in WGS84.
            parameters: Processing parameters (date).
        """
        start_time = datetime.now()
        from globalurbanmapper_gee import api, auth

        creds = _resolve_credentials()
        logger.info(
            "Initializing Earth Engine (project=%s, sa=%s)",
            creds["project"],
            creds["service_account"],
        )
        auth.initialize(
            project=creds["project"] or None,
            service_account=creds["service_account"],
            key_file=creds["key_file"],
        )

        self.data_dir = self.base_output_dir / task_id / "data"
        imagery_dir = self.data_dir / "imagery"
        imagery_dir.mkdir(parents=True, exist_ok=True)

        start_date, end_date = _composite_window(parameters.get("date", ""))
        band_list = _band_list_for_size(parameters.get("model_size", ""))
        logger.info(
            "GEE composite window: %s .. %s | band_list=%s (model_size=%s)",
            start_date,
            end_date,
            band_list,
            parameters.get("model_size"),
        )

        tiles_written = 0
        for i, bbox in enumerate(bboxes):
            sub = self.data_dir / f"_gee_bbox{i}"
            logger.info("Fetching bbox %d/%d %s from GEE", i + 1, len(bboxes), bbox)
            api.fetch_region(
                bbox=tuple(bbox),
                start_date=start_date,
                end_date=end_date,
                band_list=band_list,
                out_dir=str(sub),
                initialize=False,
            )
            # Flatten sub/imagery/*.tif into data/imagery/ with a per-bbox prefix.
            sub_imagery = sub / "imagery"
            for tif in sorted(sub_imagery.glob("*.tif")):
                dst = imagery_dir / f"b{i}_{tif.name}"
                shutil.move(str(tif), str(dst))
                tiles_written += 1
            shutil.rmtree(sub, ignore_errors=True)

        self.chips_created = tiles_written > 0
        duration = (datetime.now() - start_time).total_seconds()
        logger.info("GEE fetch wrote %d tile(s) in %.1fs", tiles_written, duration)

        return {
            "chips_created": tiles_written,
            "chip_size": parameters.get("chip_size", 512),
            "processing_duration": f"{duration:.1f}",
            "data_source": parameters.get("data_source", "GEE"),
            "target_date": parameters.get("date", "unknown"),
            "temporal_tolerance": f"±{COMPOSITE_HALF_WINDOW_DAYS}d composite window",
            "bboxes_processed": len(bboxes),
        }

    def get_data_path(self) -> Optional[str]:
        """Return the task data directory, or None"""
        if self.data_dir and self.data_dir.exists():
            return str(self.data_dir)
        return None

    def get_dataset_csv_path(self) -> Optional[str]:
        if self.data_dir and (self.data_dir / "imagery").exists():
            return str(self.data_dir / "imagery")
        return None

    def check_data_ready_for_model(self) -> bool:
        """Return True if at least one tile was fetched."""
        return self.chips_created
